chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "pureWarmAnalyze",
    title: "Pure WARM ile Doğrula",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "pureWarmAnalyze" && info.selectionText) {
    
    // Güvenli mesaj gönderme fonksiyonu
    const yeniMesajGonder = (mesaj) => {
        chrome.tabs.sendMessage(tab.id, mesaj).catch(err => {
            console.log("Sekme henüz tam yüklenmediği için mesaj iletilemedi, sorun yok.");
        });
    };

    // Panelde yükleniyor animasyonunu tetikle
    yeniMesajGonder({ action: "showLoading" });

    const selectedText = info.selectionText;

    // 1 saniyelik yapay gecikmeli analiz motoru
    setTimeout(() => {
        // Emojileri kaldırdık; content.js'in dinamik puan üretebilmesi için durum bazlı eşleme yapıyoruz
        let ratingStatus = "⭐⭐⭐⭐⭐"; 
        let reason = "Seçilen cümle bilimsel ve akademik literatür kaynaklarıyla tam örtüşmektedir.";
        let isFake = false;

        // Şüpheli kelime yakalama filtresi
        if (selectedText.toLowerCase().includes("mucize") || selectedText.toLowerCase().includes("kesin çözüm") || selectedText.toLowerCase().includes("hilesi") || selectedText.toLowerCase().includes("şok")) {
            ratingStatus = "⭐"; // content.js bu string'i yakalayıp düşük puan (0.1 - 1.7) basacak
            reason = "Yanıltıcı ve manipülatif iddia tespiti. Tıbbi ya da bilimsel bir dayanağı bulunmamaktadır.";
            isFake = true;
        }

        // İstatistikleri yerel hafızadan (storage) çek ve üzerine ekle
        chrome.storage.local.get({ taranan: 0, guvenli: 0, kirli: 0 }, (data) => {
            let yeniTaranan = data.taranan + 1;
            let yeniGuvenli = isFake ? data.guvenli : data.guvenli + 1;
            let yeniKirli = isFake ? data.kirli + 1 : data.kirli;
            
            // Verileri kaydet ve content.js tarafına nihai sonucu fırlat
            chrome.storage.local.set({ taranan: yeniTaranan, guvenli: yeniGuvenli, kirli: yeniKirli }, () => {
                yeniMesajGonder({ 
                    action: "showResult", 
                    rating: ratingStatus, 
                    reason: reason 
                });
            });
        });

    }, 1000);
  }
});
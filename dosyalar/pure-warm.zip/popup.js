document.addEventListener('DOMContentLoaded', () => {
    // Hafızadan verileri çek
    chrome.storage.local.get({ taranan: 0, guvenli: 0, kirli: 0, adblockAktif: true }, (data) => {
        document.getElementById('taranan').innerText = data.taranan;
        document.getElementById('guvenli').innerText = data.guvenli;
        document.getElementById('kirli').innerText = data.kirli;
        document.getElementById('adblock-toggle').checked = data.adblockAktif;

        // Skoru hesapla (Basit bir mantık: Güvenli / Taranan)
        if (data.taranan > 0) {
            let skor = Math.round((data.guvenli / (data.guvenli + data.kirli)) * 100);
            document.querySelector('.percent').innerText = `%${skor}`;
        }
    });

    // Adblock switch değiştiğinde kaydet
    document.getElementById('adblock-toggle').addEventListener('change', (e) => {
        chrome.storage.local.set({ adblockAktif: e.target.checked });
    });
});
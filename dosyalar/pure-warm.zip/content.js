// =========================================================================
// 🌐 PURE WARM DEV KELİME HAZNESİ VE ANALİZ KRİTERLERİ (100+ KRİTER)
// =========================================================================

const GUVENILIR_HAVUZU = [
    'üniversite', 'makale', 'tez', 'prof. dr.', 'doç. dr.', 'dr. öğr.', 'akademik', 'literatür', 
    'dergi', 'pubmed', 'ncbi', 'scopus', 'google akademik', 'doi', 'clinicaltrials', 'klinik araştırma', 
    'tübitak', 'tüba', 'who', 'fda', 'gov.tr', 'edu.tr', 'belgeli', 'onaylı', 'laboratuvar', 'analiz', 
    'veri', 'istatistik', 'resmi gazete', 'kanun', 'mevzuat', 'anayasa', 'bakanlığı', 'wikipedia', 
    'britannica', 'ansiklopedi', 'sempozyum', 'konferans', 'bülten', 'hakemli', 'indeks', 'arşiv', 
    'kütüphane', 'rasthane', 'meteoroloji', 'astronomi', 'arkeoloji', 'jeoloji', 'biyolojik', 'kimyasal'
];

const MANIPULASYON_HAVUZU = [
    'mucize', 'kesin çözüm', 'şok gelişme', 'hilesi', 'bedava', 'ücretsiz kazan', 'gizli sır', 
    'kimse bilmiyor', 'ifşa', 'patladı', 'flaş', 'son dakika şok', 'tıklayın', 'inanamayacaksınız', 
    'hayatınızı değiştirecek', 'bunu yapan yandı', 'büyük tehlike', 'herkes bunu konuşuyor', 'ortam gerildi', 
    'rezalet', 'skandal', 'çıldırdı', 'delirdi', 'şaşırtan', 'bakın ne yaptı', 'görenler şok', 'asla yapmayın', 
    'bunu biliyor muydunuz', 'ölümcül', 'dehşet', 'korkunç', 'gizlenen gerçek', 'yasaklanan', 'sansürlenen', 
    'şoke eden', 'şaşkınlık yarattı', 'gündeme bomba gibi düştü', 'yok artık', 'pes dedirtti', 'akıllara zarar', 
    'yuh', 'o anlar', 'canlı izle bedava', 'hile kodları', 'crack indir', 'full indir free',
    'paraya para demeyeceksiniz', 'zengin olma', 'kripto tüyo', 'kesin kazanç', 'yatırım tavsiyesi', 
    'garanti kazanç', 'hisse uçuyor', 'taktik', 'açıklandı ama', 'günde 5000', 'evden çalışarak', 
    'linkten ücretsiz', 'profildeki link', 'parayı katlayın', 'kısa yoldan', 'büyük vurgun', 'kaçırmayın',
    'korona ilacı', 'kanser çözümü', '1 gecede', 'yağ yakan çay', 'gençlik iksiri', 'otlar ile tedavi', 
    'büyü', 'mucizevi formül', 'doktorları çıldırtan', 'eczane gizliyor', 'hastalığa son', 'kesin tedavi'
];

const REKLAM_KEYWORDS = [
    'sponsorlu', 'promoted', 'reklam', 'ad', 'iş birliği', '#reklam', '#isbirligi', 'advertisement', 'sponsored'
];

const webReklamSeleticileri = [
    '.adsbygoogle', 'ins.adsbygoogle', '[id^="div-gpt-ad"]', 'iframe[id^="aswift_"]', '#taw', '#bottomads', 
    'div[data-ad-client]', 'iframe[name^="google_ads_iframe"]', '.gads',
    '.ad-container', '.ad-wrapper', '.banner-ads', '.advertisement', '.promo-banner', 
    '[class*="sponsored"]', '[class*="advert"]', '[id*="banner-ad"]', '[class*="AdBox"]',
    '.ad-slot', '.ad_placement', '.ad-unit',
    '.trc_rbox_container', '.OUTBRAIN', '.taboola-container', '[id^="taboola-"]', 
    '.mgbox', '.mgline', '.yandex-rtb', '[id^="yandex_rtb"]', '.teads-inread', 
    '.ytd-companion-slot-renderer', '.ytd-in-feed-ad-layout-renderer', '.ytd-ad-slot-renderer',
    '#player-ads', '#masthead-ad', 'ytd-action-companion-ad-renderer'
];

// =========================================================================
// ⭐ YILDIZ VE PUAN ÜRETİM YARDIMCISI (0.1 - 5.0 TABANLI)
// =========================================================================
function yildizArayuzuOlustur(puan) {
    let yildizlarHTML = "";
    let yuvarlanmisPuan = Math.round(puan);
    for (let i = 1; i <= 5; i++) {
        if (i <= yuvarlanmisPuan) {
            yildizlarHTML += `<span style="color: #FBBF24; font-size: 14px;">★</span>`;
        } else {
            yildizlarHTML += `<span style="color: #475569; font-size: 14px;">★</span>`;
        }
    }
    return yildizlarHTML;
}

// =========================================================================
// 1. MOTOR: GOOGLE ARAMA SONUÇLARI DERECELENDİRME VE FİLTRELEME
// =========================================================================
function filterAndSortGoogleResults() {
    if (!window.location.href.includes("google.com")) return;

    document.querySelectorAll('#tvcap, #bottomads, .commercial-unit-desktop-top, .commercial-unit-desktop-bottom').forEach(el => el.remove());

    const mainContainer = document.querySelector('div#rso');
    if (!mainContainer) return;

    const searchResults = document.querySelectorAll('div.g, div.MjjYud');
    const ignoreList = ['dizi', 'film', 'izle', 'netflix', 'oyun', 'imdb', 'torrent', 'satinal', 'trendyol', 'fiyat', 'shop'];

    let highTrustElements = [];
    let counterTaranan = 0; let counterGuvenli = 0; let counterKirli = 0;

    searchResults.forEach(result => {
        const heading = result.querySelector('h3');
        const linkElement = result.querySelector('a');
        const snippetElement = result.querySelector('div.VwiC3b, div.muS7C, span.st');

        if (heading && linkElement) {
            const url = linkElement.href.toLowerCase();
            const textContent = (heading.innerText + " " + (snippetElement ? snippetElement.innerText : "")).toLowerCase();

            let shouldIgnore = ignoreList.some(keyword => url.includes(keyword) || textContent.includes(keyword));
            if (shouldIgnore) return;

            counterTaranan++;

            if (!result.querySelector('.pure-warm-wrapper')) {
                const wrapper = document.createElement('div');
                wrapper.className = 'pure-warm-wrapper';
                
                // Tasarım artık sitenin altında değil, YANINDA (sağda) konumlanıyor
                wrapper.style.cssText = "float: right; display: flex; flex-direction: column; align-items: flex-end; background: linear-gradient(145deg, #1e293b, #0f172a); border: 1px solid rgba(251, 191, 36, 0.25); border-radius: 12px; padding: 10px 14px; margin-left: 16px; margin-bottom: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); min-width: 125px; font-family: sans-serif; color: #f8fafc;";

                let guvenliPuan = GUVENILIR_HAVUZU.filter(kriter => textContent.includes(kriter)).length;
                let kirliPuan = MANIPULASYON_HAVUZU.filter(kriter => textContent.includes(kriter)).length;
                let hesaplanmisPuan = 3.5;

                if (guvenliPuan > 0 && guvenliPuan >= kirliPuan) {
                    hesaplanmisPuan = (4.0 + (Math.min(guvenliPuan, 5) / 5) * 1.0).toFixed(1);
                    if (hesaplanmisPuan > 5.0) hesaplanmisPuan = "5.0";
                    
                    wrapper.style.borderRight = '3px solid #FBBF24';
                    result.setAttribute('data-warm-score', '5');
                    highTrustElements.push(result);
                    counterGuvenli++;
                } 
                else if (kirliPuan > 0) {
                    hesaplanmisPuan = (0.1 + (Math.random() * 1.4)).toFixed(1);
                    wrapper.style.borderRight = '3px solid #ef4444';
                    result.setAttribute('data-warm-score', '1');
                    counterKirli++;
                } 
                else {
                    hesaplanmisPuan = (2.5 + (Math.random() * 1.2)).toFixed(1);
                    wrapper.style.borderRight = '3px solid #64748b';
                    result.setAttribute('data-warm-score', '4');
                }

                const yildizlarGörünümü = yildizArayuzuOlustur(parseFloat(hesaplanmisPuan));

                // Arama sonuçlarında analiz metni tamamen silindi, sadece premium puan ve logo kaldı
                wrapper.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px; width: 100%; justify-content: flex-end;">
                        <div style="letter-spacing: 1px; display: flex; align-items: center;">${yildizlarGörünümü}</div>
                        <div style="color: #FDE68A; font-weight: 800; font-size: 15px; min-width: 24px; text-align: right;">${hesaplanmisPuan}</div>
                    </div>
                    <div style="text-align: right; line-height: 1.2; width: 100%;">
                        <div style="font-size: 13px; font-weight: 800; font-style: italic; letter-spacing: 0.5px;">
                            <span style="color: white;">Pure</span> <span style="color: #FBBF24;">WARM</span>
                        </div>
                        <div style="color: #94a3b8; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-top: 1px;">
                            Derecesi
                        </div>
                    </div>
                `;

                // Yan yana temiz durması için arama sonucunun en başına yerleştiriyoruz
                result.insertBefore(wrapper, result.firstChild);
            }
        }
    });

    highTrustElements.forEach(element => {
        if (mainContainer.firstChild !== element) {
            mainContainer.insertBefore(element, mainContainer.firstChild);
        }
    });

    if (counterTaranan > 0) {
        chrome.storage.local.get({ taranan: 0, guvenli: 0, kirli: 0 }, (data) => {
            chrome.storage.local.set({
                taranan: data.taranan + counterTaranan,
                guvenli: data.guvenli + counterGuvenli,
                kirli: data.kirli + counterKirli
            });
        });
    }
}

// =========================================================================
// 2. MOTOR: REKLAM ENGELLEME VE SOSYAL MEDYA KALKANLARI
// =========================================================================
function sosyalMedyaKalkani() {
    chrome.storage.local.get(['adblockAktif'], (data) => {
        if (data.adblockAktif === false) return;

        const currentUrl = window.location.href.toLowerCase();

        webReklamSeleticileri.forEach(secici => {
            document.querySelectorAll(secici).forEach(el => el.remove());
        });

        if (currentUrl.includes("x.com") || currentUrl.includes("twitter.com")) {
            document.querySelectorAll('article[data-testid="tweet"]').forEach(tweet => {
                const tweetText = tweet.innerText.toLowerCase();
                let sponsorluMu = REKLAM_KEYWORDS.some(word => tweetText.includes(word));
                if (sponsorluMu) {
                    tweet.closest('div[data-testid="cellInnerDiv"]')?.remove();
                }
            });
        }

        if (currentUrl.includes("youtube.com")) {
            document.querySelectorAll('ytd-rich-item-renderer:has(#ad-text), ytd-promoted-video-renderer, ytd-display-ad-renderer, .ytd-carousel-ad-renderer-v2').forEach(el => el.remove());
            
            document.querySelectorAll('ytd-rich-grid-media, ytd-video-renderer').forEach(video => {
                const titleEl = video.querySelector('#video-title');
                if (titleEl) {
                    const titleText = titleEl.innerText.toLowerCase();
                    let clickbaitMi = MANIPULASYON_HAVUZU.slice(0, 30).some(word => titleText.includes(word));
                    if (clickbaitMi && !video.querySelector('.warm-warning')) {
                        video.style.opacity = "0.4";
                        video.style.border = "1px dashed #ef4444";
                        video.style.borderRadius = "8px";
                    }
                }
            });
        }

        if (currentUrl.includes("instagram.com")) {
            document.querySelectorAll('article').forEach(post => {
                const postText = post.innerText.toLowerCase();
                if (postText.includes('sponsorlu') || postText.includes('sponsored')) {
                    post.remove();
                }
            });
        }
    });
}

// =========================================================================
// 🎥 YOUTUBE VİDEO İÇİ REKLAM ATLATMA ALGORİTMASI (GÜVENLİ SÜRÜM)
// =========================================================================
function youtubeVideoReklamAvcisi() {
    if (!window.location.href.includes("youtube.com/watch")) return;

    const video = document.querySelector('video');
    const player = document.querySelector('.html5-video-player');
    
    if (!video || !player) return;

    const reklamDevredeMi = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');

    if (reklamDevredeMi) {
        video.muted = true;
        video.playbackRate = 16;
        
        if (isFinite(video.duration) && video.currentTime < (video.duration - 0.5)) {
            video.currentTime = video.duration - 0.1;
        }
    } else {
        if (video.playbackRate === 16) {
            video.playbackRate = 1;
            video.muted = false;
        }
    }

    const ytbGecButonlari = [
        '.ytp-skip-ad-button', 
        '.ytp-ad-skip-button', 
        '.ytp-ad-skip-button-modern', 
        'button.ytp-ad-skip-button'
    ];

    ytbGecButonlari.forEach(secici => {
        const buton = document.querySelector(secici);
        if (buton) {
            buton.click();
        }
    });
}

// =========================================================================
// 3. MOTOR: ANA TETİKLEYİCİ VE SAĞ TIK AI ARABİRİMİ (METİN SEÇİMİ)
// =========================================================================
function pureWarmAnaMotor() {
    filterAndSortGoogleResults();
    sosyalMedyaKalkani();
    youtubeVideoReklamAvcisi();
}

pureWarmAnaMotor();
const observer = new MutationObserver(pureWarmAnaMotor);
observer.observe(document.body, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    let existBox = document.getElementById('pure-warm-ai-box');
    if (existBox) existBox.remove();

    const aiBox = document.createElement('div');
    aiBox.id = 'pure-warm-ai-box';
    
    // Sağ tık arayüzü premium karanlık/altın temaya uyarlandı
    aiBox.style.cssText = "position:fixed; bottom:30px; right:30px; width:320px; background:linear-gradient(145deg, #1e293b, #0f172a); border:1px solid rgba(251, 191, 36, 0.4); box-shadow:0 15px 40px rgba(0,0,0,0.5); border-radius:14px; padding:15px; z-index:9999999; font-family:sans-serif; box-sizing:border-box; color: white;";

    if (message.action === "showLoading") {
        aiBox.innerHTML = `
            <div style="font-weight:bold; font-size:14px; color:#FBBF24; margin-bottom:5px; font-style:italic;">Pure WARM AI Görevde...</div>
            <div style="font-size:12px; color:#cbd5e1; display:flex; align-items:center; gap:8px;">
                <div style="width:12px; height:12px; border:2px solid #FBBF24; border-top-color:transparent; border-radius:50%; animation: spin 1s linear infinite;"></div>
                Metin katmanları analiz ediliyor...
            </div>
            <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
        `;
        document.body.appendChild(aiBox);
    } 
    else if (message.action === "showResult") {
        // Metin analizinde 0.1 - 5.0 arası puanlama mantığı ve yapay zeka analizi korundu
        let aiPuan = message.rating === "⭐⭐⭐⭐⭐" ? (4.5 + Math.random() * 0.5).toFixed(1) : (0.5 + Math.random() * 1.2).toFixed(1);
        let aiYildizlar = yildizArayuzuOlustur(parseFloat(aiPuan));

        aiBox.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:6px; margin-bottom:8px;">
                <span style="font-weight:bold; color:white; font-size:14px; font-style:italic;">Pure <span style="color:#FBBF24;">WARM</span> AI</span>
                <button id="close-warm-box" style="background:none; border:none; cursor:pointer; font-weight:bold; color:#94a3b8; font-size:14px;">✕</button>
            </div>
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                <div style="display:flex; align-items:center;">${aiYildizlar}</div>
                <div style="color: #FDE68A; font-weight: 800; font-size: 15px;">${aiPuan}</div>
            </div>
            <div style="font-size:12px; color:#cbd5e1; line-height:1.4; font-weight:500;">
                <span style="color: #FBBF24; font-weight: bold;">🤖 WARM Derin Analiz:</span> ${message.reason}
            </div>
        `;
        document.body.appendChild(aiBox);
        document.getElementById('close-warm-box').addEventListener('click', () => aiBox.remove());
    }
});